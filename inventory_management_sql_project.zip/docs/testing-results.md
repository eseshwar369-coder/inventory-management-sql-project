# Testing Plan and Results

## Status

This file is a test plan template. Record actual results after running each test in MySQL Workbench. Do not mark a test as passed until you have observed its outcome.

| Test | Expected outcome | Actual outcome |
|---|---|---|
| Product category foreign-key integrity query | 0 orphan products | Pending |
| Sales product foreign-key integrity query | 0 orphan sales | Pending |
| Non-positive product price check | 0 invalid rows | Pending |
| Negative stock check | 0 invalid rows | Pending |
| Negative quantity check | 0 invalid rows | Pending |
| Product-level vs category-level total units | Totals reconcile | Pending |
| Stock-status boundaries: 0, 10, 11 | Out of stock, low stock, in stock | Pending |
| Guarded stock deduction for more units than available | 0 rows updated; transaction rolled back | Pending |
| Unsold-products report | Only products with no matching sales rows | Pending |

## Important safety notes

- Run setup and negative tests against a disposable demo database, not a production database.
- To test a `CHECK` constraint, try one invalid `INSERT` or `UPDATE` at a time and confirm that MySQL rejects it. Then verify that no invalid row was created.
- The stock guard demonstration in `sql/06_testing.sql` is rolled back. Confirm the affected-row count is zero in the demo data.
- The database's foreign keys do not, by themselves, prevent overselling.
- If your current database contains real or important data, back it up before making schema changes.
