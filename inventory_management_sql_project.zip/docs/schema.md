# Database Schema

## Entity relationship overview

The database contains three entities:

- **Categories**: lookup table for product classifications.
- **Product**: products, their category, current unit price, and current stock.
- **Sales**: dated records of quantities sold for a product.

Relationships:

1. `categories.category_id` → `product.category_Id` (one category to many products).
2. `product.product_id` → `sales.product_id` (one product to many sales records).

## Integrity rules

- Each table has a primary key.
- Product category references must point to an existing category.
- Sales product references must point to an existing product.
- Unit prices must be positive.
- Stock and recorded sales quantities must be non-negative.

In the demo schema, these validation rules are implemented as `CHECK` constraints. MySQL versions before 8.0.16 parse but do not enforce `CHECK` constraints, so use a supported version and verify behavior.

## Design considerations

The `sales` table records product, date, and quantity but does not store sale price. Therefore, this schema supports unit-volume reports but does not support accurate historical revenue calculations when prices change.

`Unitin_stock` is a current-state value. The schema does not by itself define whether the value is updated when a sales row is inserted. A production implementation should process stock deduction and sale insertion atomically, typically within a transaction.
