-- Sales reports.
-- Change the USE statement to USE inventryDB; to run against your existing project database.
USE inventory_management_demo;

-- Report 1: Total units sold by product (includes products with no sales).
SELECT
    p.product_id,
    p.product_name,
    COALESCE(SUM(s.quantity_sold), 0) AS total_units_sold
FROM product AS p
LEFT JOIN sales AS s
    ON p.product_id = s.product_id
GROUP BY p.product_id, p.product_name
ORDER BY total_units_sold DESC, p.product_id;

-- Report 2: Total units sold by category (includes categories with no sales).
SELECT
    c.category_id,
    c.category_name,
    COALESCE(SUM(s.quantity_sold), 0) AS total_units_sold
FROM categories AS c
LEFT JOIN product AS p
    ON c.category_id = p.category_Id
LEFT JOIN sales AS s
    ON p.product_id = s.product_id
GROUP BY c.category_id, c.category_name
ORDER BY total_units_sold DESC, c.category_id;

-- Report 5: Monthly sales trends (chronological year-month order).
SELECT
    DATE_FORMAT(sales_date, '%Y-%m') AS sales_month,
    SUM(quantity_sold) AS total_units_sold
FROM sales
GROUP BY DATE_FORMAT(sales_date, '%Y-%m')
ORDER BY sales_month ASC;
