-- Synthetic sample data for the fresh inventory_management_demo database.
-- Run sql/01_create_tables.sql first.
USE inventory_management_demo;

INSERT INTO categories (category_id, category_name) VALUES
(101, 'Electronics'),
(102, 'Mobile Devices'),
(103, 'Audio Accessories'),
(104, 'Home Appliances');

INSERT INTO product
    (product_id, product_name, category_Id, Unit_price, Unitin_stock)
VALUES
(1, 'Laptop', 101, 65000.00, 8),
(2, 'Desktop Computer', 101, 52000.00, 15),
(3, 'Smartphone', 102, 28000.00, 5),
(4, 'Tablet', 102, 18000.00, 0),
(5, 'Headphones', 103, 2500.00, 22),
(6, 'Portable Speaker', 103, 4200.00, 7),
(7, 'Microwave Oven', 104, 8500.00, 4),
(8, 'Refrigerator', 104, 32000.00, 6),
(9, 'Digital Camera', 101, 24000.00, 3),
(10, 'Vacuum Cleaner', 104, 7000.00, 12);

INSERT INTO sales (sales_Id, product_id, sales_date, quantity_sold) VALUES
(1, 1, '2024-01-10', 2),
(2, 2, '2024-01-16', 3),
(3, 3, '2024-01-20', 4),
(4, 5, '2024-02-02', 5),
(5, 6, '2024-02-12', 2),
(6, 7, '2024-02-18', 1),
(7, 1, '2024-03-03', 1),
(8, 3, '2024-03-14', 2),
(9, 8, '2024-03-20', 1),
(10, 2, '2024-04-05', 2),
(11, 5, '2024-04-11', 3),
(12, 9, '2024-04-22', 1);
