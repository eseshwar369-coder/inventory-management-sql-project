-- Fresh demo setup for the Inventory Management SQL project.
-- WARNING: This drops and recreates tables in inventory_management_demo.
-- Do NOT run against your existing inventrydb database.

CREATE DATABASE IF NOT EXISTS inventory_management_demo;
USE inventory_management_demo;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS sales;
DROP TABLE IF EXISTS product;
DROP TABLE IF EXISTS categories;
SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE categories (
    category_id INT NOT NULL,
    category_name VARCHAR(100) NOT NULL,
    PRIMARY KEY (category_id),
    CONSTRAINT uq_categories_name UNIQUE (category_name)
) ENGINE=InnoDB;

CREATE TABLE product (
    product_id INT NOT NULL,
    product_name VARCHAR(70) NOT NULL,
    category_Id INT NOT NULL,
    Unit_price DECIMAL(10,2) NOT NULL,
    Unitin_stock INT NOT NULL,
    PRIMARY KEY (product_id),
    INDEX idx_product_category (category_Id),
    CONSTRAINT fk_product_category
        FOREIGN KEY (category_Id) REFERENCES categories(category_id),
    CONSTRAINT chk_product_price_positive CHECK (Unit_price > 0),
    CONSTRAINT chk_product_stock_nonnegative CHECK (Unitin_stock >= 0)
) ENGINE=InnoDB;

CREATE TABLE sales (
    sales_Id INT NOT NULL,
    product_id INT NOT NULL,
    sales_date DATE NOT NULL,
    quantity_sold INT NOT NULL,
    PRIMARY KEY (sales_Id),
    INDEX idx_sales_product (product_id),
    INDEX idx_sales_date (sales_date),
    CONSTRAINT fk_sales_product
        FOREIGN KEY (product_id) REFERENCES product(product_id),
    CONSTRAINT chk_sales_quantity_nonnegative CHECK (quantity_sold >= 0)
) ENGINE=InnoDB;
