-- Reference implementation of validation constraints for the fresh demo schema.
-- The fresh setup in 01_create_tables.sql already creates these constraints.
-- This file documents the rules and provides inspection queries.
-- Do not re-add the constraints if they already exist in your database.

USE inventory_management_demo;

SHOW CREATE TABLE categories;
SHOW CREATE TABLE product;
SHOW CREATE TABLE sales;

-- Expected rules:
-- product.Unit_price > 0
-- product.Unitin_stock >= 0
-- sales.quantity_sold >= 0
-- product.category_Id references categories.category_id
-- sales.product_id references product.product_id

-- For an existing database, inspect first with SHOW CREATE TABLE.
-- Add only constraints that are missing, after checking for invalid existing rows.
