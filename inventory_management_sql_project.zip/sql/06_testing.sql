-- Read-only integrity checks and a safe guarded-update demonstration.
-- Run against the demo database first. Change USE only if you know the target schema.
USE inventory_management_demo;

-- Test 1: products whose category reference has no match (expected: 0 rows when FK is active).
SELECT p.product_id, p.category_Id
FROM product AS p
LEFT JOIN categories AS c ON c.category_id = p.category_Id
WHERE c.category_id IS NULL;

-- Test 2: sales whose product reference has no match (expected: 0 rows when FK is active).
SELECT s.sales_Id, s.product_id
FROM sales AS s
LEFT JOIN product AS p ON p.product_id = s.product_id
WHERE p.product_id IS NULL;

-- Test 3: invalid values already present (each query should return 0 rows).
SELECT * FROM product WHERE Unit_price <= 0;
SELECT * FROM product WHERE Unitin_stock < 0;
SELECT * FROM sales WHERE quantity_sold < 0;

-- Test 4: report reconciliation.
-- Total units across product report should equal total units in sales.
SELECT COALESCE(SUM(quantity_sold), 0) AS total_units_in_sales
FROM sales;

-- Test 5: guarded stock update demonstration.
-- This attempts to deduct 999 units from product 1 only if at least 999 are in stock.
-- With the sample data, the UPDATE should affect 0 rows. ROLLBACK ensures no changes persist.
START TRANSACTION;
UPDATE product
SET Unitin_stock = Unitin_stock - 999
WHERE product_id = 1
  AND Unitin_stock >= 999;
SELECT ROW_COUNT() AS rows_updated_expected_zero;
ROLLBACK;

-- Important: a guarded UPDATE is only one part of a sale workflow.
-- A real workflow should check the affected-row count, insert the sales record only
-- if stock deduction succeeded, and commit both actions in one transaction.
-- A foreign key alone does not prevent selling more units than are available.
